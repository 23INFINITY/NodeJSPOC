//require('dotenv').config;
const express = require('express');
const app = express();
const port = process.env.PORT || 3000 ;
const bodyParser = require('body-parser');
const cors = require('cors');
const todoRoutes = require('./Routes/todo');

//db conn
require('./config/database');

app.use(cors());
app.use(bodyParser.urlencoded({extended: true}));

//routes
app.use('./api/todos', todoRoutes);

//server running status
app.listen(port, () => {
    console.log('The app is listening at http://localhost: ',{port})
} );